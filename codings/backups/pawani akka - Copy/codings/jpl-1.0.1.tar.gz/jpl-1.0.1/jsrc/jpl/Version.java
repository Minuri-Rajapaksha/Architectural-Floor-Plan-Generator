// $Id: Version.java,v 1.14 1999/05/05 20:29:54 fadushin Exp $
package jpl;
class Version
{
	public final java.lang.String status = "final";
	public final int    major            = 1;
	public final int    minor            = 0;
	public final int    patch            = 1;
}
