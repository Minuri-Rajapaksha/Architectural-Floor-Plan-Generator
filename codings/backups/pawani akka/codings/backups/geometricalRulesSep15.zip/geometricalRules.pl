housePlan(T) :- polygon(T).
housePlan([H|T]) :- polygon(H), housePlan(T).

line([[X1,Y1],[X2,Y2]]) :- integer(X1), integer(X2), integer(Y1), integer(Y2).


polygon(T):- polygonBasic([[X1,Y1],[X2,Y2]],[[X2,Y2],[X3,Y3]],[[X3,Y3],[X1,Y1]]).
polygon([H|T]) :- line(H), polygon(T).

polygonBasic([[X1,Y1],[X2,Y2]],[[X2,Y2],[X3,Y3]],[[X3,Y3],[X1,Y1]]).


% adjacentLine([[X1,Y1],[X2,Y2]],[[X3,Y3],[X4,Y4]], T1, T2) :- T1 is
% (Y2-Y1)/(X2-X1), T2 is (Y4-Y3)/(X4-X3), T1 is T2, (Y1-Y3)/(X1-X3) = T1,
% Sqrt(2,(((X1-X2)*(X1-X2))+((Y1-Y2)*(Y1-Y2)))) = (Sqrt(2,
% (((X1-X3)*(X1-X3))+((Y1-Y3)*(Y1-Y3)))) + Sqrt(2, (((X3-X2)*(X3-X2) +
% ((Y3-Y2)*(Y3-Y2)))))).



%area(T,A) :- line(T), findArea(T,A).
%area([H|T],A) :- line(H), area(T,A1), A is A+A1.

%findArea([[X,Y],[X1,Y1]],A) :- A is (((Y1+Y)/2) * (X1-X)).

%  polygon code

% polygonNew(T) :-
% polygonNew([[[X1,Y1],[X2,Y2]]|[[[X3,Y3],[X4,Y4]]|T]]) :- line()

lengthL([],0).
lengthL([H|T],N) :- lengthL(T,N2), N is N2+1.

checkPolygon([H|T]) :- lengthL([H|T],N), findNth([H|T],N,X), checkFirstAndLast(H,X).

polygonNew([H|[HT|T]]).
polygonNew([H|[HT|T]]) :- line(H), line(HT), checkFirstAndSecond(H,HT).

checkFirstAndSecond([[X1,Y1],[X2,Y2]], [[X3,Y3],[X4,Y4]]) :- X2=X3, Y2=Y3.

checkFirstAndLast([[X1,Y1],[X2,Y2]], [[X3,Y3],[X4,Y4]]) :-  X1=X4, Y1=Y4.

findNth(T,X) :- X is T.
findNth([H|T],X) :- findNth(T,X).

% correct methods - definition of a polygon

isClosed([[X1,Y1]|L]) :- last(L, [X2,X1]).

isConnected([[X1,Y1],[Y1,Z1]]).
isConnected([[X1,Y1]|[[Y1,Z1]|L]]):- isConnected([[Y1,Z1]|L]).


polygon(X) :- isClosed(X), isConnected(X).

% check adjacency of two polygons

adjacent([H|T],[H1|T1]) :- findNth([H|T],X), findNth([H1|T1],X).



