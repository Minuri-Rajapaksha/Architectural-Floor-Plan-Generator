housePlan(T) :- polygon(T).
housePlan([H|T]) :- polygon(H), housePlan(T).

line([[X1,Y1],[X2,Y2]]) :- integer(X1), integer(X2), integer(Y1), integer(Y2).

polygon([H|T]) :- line(H), polygon(T).

polygon([[X1,Y1],[X2,Y2]],[[X2,Y2],[X3,Y3]],[[X3,Y3],[X1,Y1]]).


