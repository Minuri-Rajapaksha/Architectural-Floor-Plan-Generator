% To write the output of the prolog predicate to a text file
% lengthL([1,2,3,4,5],N), open('out.txt', write, Out), write(Out,N),
% close(Out).

% Depth Limit Code
prove(true,N):-N>0.
prove((Goal1,Goal2),N):-N>0,prove(Goal1,N),prove(Goal2,N).
prove(Goal,D):-D>0,dif(true,Goal),X is D-1,clause(Goal,Body),prove(Body,X).



% Definition to the house plan - H,T are polygons
housePlan(T) :- polygon(T).
housePlan([H|T]) :- polygon(H), housePlan(T).



% Definition to line
line([[X1,Y1],[X2,Y2]]) :- between(1,2,X1), between(1,2,X2),between(1,2,Y1),between(1,2,Y2).



% Definition to polygon

polygon(X) :- isClosed(X), isConnected(X).

	isClosed([[X1,Y1]|L]) :- last(L, [X2,X1]).

	isConnected([[X1,Y1],[Y1,Z1],[Z1,U1]]):- line([X1,Y1]),line([Y1,Z1]),line([Z1,U1]).

	isConnected([[X1,Y1]|[[Y1,Z1]|L]]):- isConnected([[Y1,Z1]|L]), line([X1,Y1]),line([Y1,Z1]).



% Find the adjacency of two lines, pass two polygons as the parameters

adjacent(X,Y) :-  findMember(X,[A,B]), findMember(Y,[A,B]).
adjacent(X,Y) :-  findMember(X,[A,B]), findMember(Y,[B,A]).

	% To find a member variable
	findMember([X|T],X) .
	findMember([H|T],X) :- findMember(T,X).


% To add element to a list
addToList(H,[H|T],T).
addToList(X,[H|T],[H|R]) :- addToList(X,T,R).


% get set of polygons and add all the coordinates of the polygons into one list

housePlanLineList([P1,P2], HL) :-  append(P1, P2, HL).
housePlanLineList([P1|[P2|PN]], HL) :-  append(P1, P2, L1), housePlanLineList(PN, L2), append(L1,L2,HL).

findCenterStep1([[X1,Y1],[X2,Y2]], XC, YC, N) :- XC is X1 + X2, YC is Y1 + Y2, N is 1.
findCenterStep1([[X1,Y1]|[[X2,Y2]|LN]], XC, YC, N) :- XT is X1 + X2, YT is Y1 + Y2, findCenterStep1(LN, XP, YP, N1), N is N1+1, XC is XT + XP, YC is YT + YP.


% to count number of times that an element exists in a list - correct
occurrences([],_,0).
occurrences([X|Y],X,N):- occurrences(Y,X,W),N is W + 1.
occurrences([X|Y],Z,N):- occurrences(Y,Z,N),X\=Z.

% correct code to find the boundry of a house
boundary([],R,R).
boundary([H|L],T,R) :- occurrences(L,H,N), N>=1, deleteMe(H,T,R1), deleteMe(H,R1,R2), boundary(L,R2,R).
boundary([H|L],T,R) :- occurrences(L,H,N), N<1, boundary(L,T,R).

% to order the lines
%orderBoundary([],R,R).
% orderBoundary([[X,Y]|[[Z,U]|L]], T, R) :- X is Z,
% append([X,Y],R1,R4),append([Z,U],R4,R), deleteMe([X,Y],T,R2),
% deleteMe([Z,U],R2,R3), orderBoundary(L,R3,R).
% orderBoundary([[X,Y]|[[Z,U]|L]], T, R) :- X is U,
% append([X,Y],R1,R4),append([U,Z],R4,R), deleteMe([X,Y],T,R2),
% deleteMe([Z,U],R2,R3), orderBoundary(L,R3,R).

% to order the lines, T = [[X,Y]|[[Z,U]|L]]
orderBoundary([],R,R).
orderBoundary([[X,Y]|[[Z,U]|L]], T, R) :- X is Z, append([X,Y],R1,R4),append([Z,U],R4,R), orderBoundary(L,R3,R).
orderBoundary([[X,Y]|[[Z,U]|L]], T, R) :- X is U, append([X,Y],R1,R4),append([U,Z],R4,R), orderBoundary(L,R3,R).



% Terminate recursive calling if deleting element apprears twice
deleteMe(H,[H|T],T):- !.
deleteMe(X,[H|T],[H|R]) :- deleteMe(X,T,R).

noBothRoomPrivate(X,Y) :- countMe(X,Y).
%noSpecialPrivacy(X,Y) :- countMe(X,Y).

path(X,Y,[],N) :- adjacent(X,Y), noBothRoomPrivate(X,Y).
path(X,Y,[Z|I],N) :- N>0, N2 is N-1, adjacent(X,Z), noBothRoomPrivate(X,Z), path(Z,Y,I,N2).


% ---------------- Interim Progress IV -------------------- %

% Testings
repeatMy.
repeatMy :- repeatMy.
dosquares :- repeatMy, read(X), (X = stop, !; Y is X*X, write(Y),fail).
writeHousePlan :- open('house.txt', write, Out), housePlan(A), write(Out,A).

% to write all the generated house plans into one text file
writeHousePlanMy :- open('house.txt', write, Out), housePlan(A), read(X), (X = stop, close(Out), !;  writeq(Out,A),fail).


% validate house plan is a set of polygons and the polygons are
% adjacent, H is a polygon contains list of lines
checkHousePlan([H|T]) :- housePlan([H|T]), interconnected([H|T],[H|T]), length([H|T],Length), Length>2.


% A = [G|[H|T]], check whether a set of polygons is interconnected.
interConnected([H],L).
interconnected([H|T],A) :- isAdjacentMemberMy(H,A), interconnected(T,A).

%isAdjacentMemberMy(M,L) :- member(X,L), adjacent(X,M).

isAdjacentMemberMy(M,L) :- findMember(L,X), adjacent(X,M).


% ------------------ Find the area of a polygon --------------- %

% pass a polygon and return the area of the polygon
:- use_module(library(clpfd)).
findArea([[[A,B],[C,D]]|T], AR) :- Y #= (B+D)/2, X #= D-A, A1 #= Y*X, findArea(T,A2), AR is A1+A2.


% ----------------- Find the width of a polygon ---------------- %

findWidth([[[A,B],[C,D]]|T], L) :-






