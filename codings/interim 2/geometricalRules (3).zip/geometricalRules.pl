% To write the output of the prolog predicate to a text file
% lengthL([1,2,3,4,5],N), open('out.txt', write, Out), write(Out,N),
% close(Out).

% Depth Limit Code
prove(true,N):-N>0.
prove((Goal1,Goal2),N):-N>0,prove(Goal1,N),prove(Goal2,N).
prove(Goal,D):-D>0,dif(true,Goal),X is D-1,clause(Goal,Body),prove(Body,X).



% Definition to the house plan - H,T are polygons
housePlan(T) :- polygon(T).
housePlan([H|T]) :- polygon(H), housePlan(T).



% Definition to line
line([[X1,Y1],[X2,Y2]]) :- between(1,2,X1), between(1,2,X2),between(1,2,Y1),between(1,2,Y2).



% Definition to polygon

polygon(X) :- isClosed(X), isConnected(X).

	isClosed([[X1,Y1]|L]) :- last(L, [X2,X1]).

	isConnected([[X1,Y1],[Y1,Z1],[Z1,U1]]):- line([X1,Y1]),line([Y1,Z1]),line([Z1,U1]).

	isConnected([[X1,Y1]|[[Y1,Z1]|L]]):- isConnected([[Y1,Z1]|L]), line([X1,Y1]),line([Y1,Z1]).



% Find the adjacency of two lines, pass two polygons as the parameters

adjacent(X,Y) :-  findMember(X,[A,B]), findMember(Y,[A,B]).
adjacent(X,Y) :-  findMember(X,[A,B]), findMember(Y,[B,A]).

	% To find a member variable
	findMember([X|T],X) .
	findMember([H|T],X) :- findMember(T,X).


% To add element to a list
addToList(H,[H|T],T).
addToList(X,[H|T],[H|R]) :- addToList(X,T,R).

% get set of polygons and add all the coordinates of the polygons into
% one list

housePlanLineList([P1,P2], HL) :-  append(P1, P2, HL).
housePlanLineList([P1|[P2|PN]], HL) :-  append(P1, P2, L1), housePlanLineList(PN, L2), append(L1,L2,HL).


% --------------- Find the direction of a polygon ----------------- %


% to count number of times that an element exists in a list - correct
occurrences([],_,0).
occurrences([X|Y],X,N):- occurrences(Y,X,W),N is W + 1.
occurrences([X|Y],Z,N):- occurrences(Y,Z,N),X\=Z.

% find the boundry of a house
boundary([],R,R).
boundary([H|L],T,R) :- occurrences(L,H,N), N>=1, deleteMe(H,T,R1), deleteMe(H,R1,R2), boundary(L,R2,R).
boundary([H|L],T,R) :- occurrences(L,H,N), N<1, boundary(L,T,R).


% to order the above found boundary lines, T = [[X,Y]|[[Z,U]|L]]
orderBoundary([],R,R).
orderBoundary([[X,Y]|[[Z,U]|L]], T, R) :- X is Z, append([X,Y],R1,R4),append([Z,U],R4,R), orderBoundary(L,R3,R).
orderBoundary([[X,Y]|[[Z,U]|L]], T, R) :- X is U, append([X,Y],R1,R4),append([U,Z],R4,R), orderBoundary(L,R3,R).


% -------------- calculate the centroid of the house -------------- %

% polygon eke points tika list ekak widihata pass karanna ona centroidX
% and centroidY ta

centroidXbasic([[X,Y],[Z,U]], X1) :- X1 #= (X+Z)*((X*U) - (Y*Z)).
centroidXbasic([[X,Y]|[[Z,U]|L]], XR ) :- X1 #= (X+Z)*((X*U) - (Y*Z)), XR #= X1+X2, centroidXbasic(L,X2).

centroidYbasic([[X,Y],[Z,U]], Y1) :- Y1 #= (Y+U)*((X*U) - (Y*Z)).
centroidYbasic([[X,Y]|[[Z,U]|L]], YR ) :- Y1 #= (Y+U)*((X*U) - (Y*Z)), YR #= Y1+Y2, centroidYbasic(L,Y2).

centroidX(A,X) :- centroidXbasic(A,XR), findArea(A,AR), X #= XR /(6*AR).
centroidY(A,Y) :- centroidYbasic(A,YR), findArea(A,AR), Y #= YR /(6*AR).

% find the length from poylgon centroid to top polygon intersecting
% point- [X,Y]=centroid of the polygon, [[[A,B],[C,D]]|[[[E,F],[G,H]]|T]] = polygon line
% list

% find lines relevant to top intersect point in polygon, [X,Y] is
% the centroid of the house polygon
findTopIntersectPoint([X,Y], [[A,B],[C,D]],R  ) :- between(A,C,X), append([],[[A,B],[C,D]],R).
findTopIntersectPoint([X,Y], [[[A,B],[C,D]]|T],R  ) :- between(A,C,X), append(R1,[[A,B],[C,D]],R), findTopIntersectPoint([X,Y], T, R1).

% calculate an intersecting point [[X1,Y1],[X2,Y2]] = line which
% contains centroid's x coordinate in its range
calculateIntersectingPoint([X3,Y3],[[X1,Y1],[X2,Y2]],XM,YM) :- XM is X3, YM #= (Y1 + (((Y2-Y1)*(X3-X1))/(X2-X1))).

% check for intersecting points
checkIntersectingPoints([X,Y],[[[A,B],[C,D]]|T], X, Y) :- calculateIntersectingPoint([X,Y], [[A,B],[C,D]], ),

% ---------------- Interim Progress IV -------------------- %

% Testings
repeatMy.
repeatMy :- repeatMy.
dosquares :- repeatMy, read(X), (X = stop, !; Y is X*X, write(Y),fail).
writeHousePlan :- open('house.txt', write, Out), housePlan(A), write(Out,A).

% to write all the generated house plans into one text file
writeHousePlanMy :- open('house.txt', write, Out), housePlan(A), read(X), (X = stop, close(Out), !;  writeq(Out,A),fail).


% validate house plan is a set of polygons and the polygons are
% adjacent, H is a polygon contains list of lines
checkHousePlan([H|T]) :- housePlan([H|T]), interconnected([H|T],[H|T]), length([H|T],Length), Length>2.


% A = [G|[H|T]], check whether a set of polygons is interconnected.

interConnected([H],L) :-  isAdjacentMemberMy(H,L).
interconnected([H|T],A) :- isAdjacentMemberMy(H,A), interconnected(T,A).

%isAdjacentMemberMy(M,L) :- member(X,L), adjacent(X,M).

isAdjacentMemberMy(M,L) :- findMember(L,X), adjacent(X,M).


% ----------------- Find the area of a polygon ----------------- %

% pass a polygon and return the area of the polygon
:- use_module(library(clpfd)).
findArea([[[A,B],[C,D]]|T], AR) :- Y #= (B+D)/2, X #= D-A, A1 #= Y*X, findArea(T,A2), AR is A1+A2.


% ----------------- Find the width of a polygon ---------------- %

% pass a polygon and gives a list of widths
findWidth([[[A,B],[C,D]],[[E,F],[G,H]]], L) :- findLength(A,G,B,H,L).
findWidth([[[A,B],[C,D]]|[[[E,F],[G,H]]|T]], L) :- findLength(A,G,B,H,L1), findWidth(T,L2), append(L2,L1,L).


% calculate the length between two coordinates coordinates are (A,B) and
% (G,H) L is the answer
findLength(A,G,B,H,L) :- L #= (A-G)*(A-G) + (B-H)*(B-H).
































% Terminate recursive calling if deleting element apprears twice
deleteMe(H,[H|T],T):- !.
deleteMe(X,[H|T],[H|R]) :- deleteMe(X,T,R).

noBothRoomPrivate(X,Y) :- countMe(X,Y).
%noSpecialPrivacy(X,Y) :- countMe(X,Y).

path(X,Y,[],N) :- adjacent(X,Y), noBothRoomPrivate(X,Y).
path(X,Y,[Z|I],N) :- N>0, N2 is N-1, adjacent(X,Z), noBothRoomPrivate(X,Z), path(Z,Y,I,N2).


